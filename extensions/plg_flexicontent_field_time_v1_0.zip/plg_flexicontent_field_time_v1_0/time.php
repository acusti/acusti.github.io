<?php
/**
 * @version		$Id: time.php 1.0 2010-07-28 14:11:51Z andrewp $
 * @package		FLEXIcontent
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

//jimport('joomla.plugin.plugin');
jimport('joomla.event.plugin');

class plgFlexicontent_fieldsTime extends JPlugin
{
	function plgFlexicontent_fieldsDate( &$subject, $params )
	{
		parent::__construct( $subject, $params );
	}

	function onDisplayField(&$field, $item)
	{
		$field->label = JText::_($field->label);
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'time') return;

		// some parameter shortcuts
		$required 			= $field->parameters->get( 'required', 0 ) ;
		//$multiple			= $field->parameters->get( 'allow_multiple', 1 ) ;
		//$maxval				= $field->parameters->get( 'max_values', 0 ) ;
								
		$required 	= $required ? ' class="required"' : '';

		// initialise property
		if (!$field->value) {
			$field->value = array();
			$field->value[0] = '';
		}
		
		$field->html	= '<div><input name="'.$field->name.'[]" type="text" value="'.$field->value[0].'"'.$required.' /></div>';
		
	}


	function onBeforeSaveField( $field, &$post, &$file )
	{
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'time') return;
		
		$newpost = array();
		$new = 0;

		foreach ($post as $n=>$v)
		{
			if ($v != '')
			{
				// validate:
				$vParts = explode(':', $v);
				if (count($vParts < 2)) {
					if (strlen($vParts[0]) > 2) {
						$vParts = array(substr($v, 0, -2), substr($v, -2));
					}
					else {
						$vParts[] = '00';
					}
				}
				$vParts[0] = (int) $vParts[0];
				$vParts[1] = (int) $vParts[1];
				if ($vParts[0] > 23)
					$vParts[0] = 0;
				if ($vParts[1] > 59)
					$vParts[1] = 0;
				if ($vParts[0] < 10)
					$vParts[0] = '0' . $vParts[0];
				if ($vParts[1] < 10)
					$vParts[1] = '0' . $vParts[1];
				
				$newpost[$new] = $vParts[0] . ':' . $vParts[1];
			}
			$new++;
		}
		$post = $newpost;
	}


	function onDisplayFieldValue(&$field, $item, $values=null, $prop='display')
	{
		$field->label = JText::_($field->label);
		// execute the code only if the field type match the plugin type
		if($field->field_type != 'date') return;
										
		$field->{$prop}	= $field->value ? $field->value : JText::_( 'FLEXI_NO_VALUE' );
	}
}
?>