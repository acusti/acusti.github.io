<?php
/**
 * @version		$Id: category_subcategories.php 1.0 2010-08-22 16:30:00Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<?php
$n = count($this->categories);
$i = 0;
?>
<div class="subcategorieslist">
	<?php
	echo JText::_( 'FLEXI_SUBCATEGORIES' ) . ' : ';
	foreach ($this->categories as $sub) :
		$subsubcount = count($sub->subcats);	
	?>
		<a href="<?php echo JRoute::_( FlexicontentHelperRoute::getCategoryRoute($sub->slug) ); ?>"><?php echo $this->escape($sub->title); ?></a>
		<?php
		if ($this->params->get('show_itemcount', 1)) echo ' (' . ($sub->assigneditems != null ? $sub->assigneditems.'/'.$subsubcount : '0/'.$subsubcount) . ')';
		$i++;
		if ($i != $n) :
			echo ', ';
		endif;
	endforeach; ?>
</div>