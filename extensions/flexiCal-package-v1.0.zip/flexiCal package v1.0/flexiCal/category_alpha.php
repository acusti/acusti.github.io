<?php
/**
 * @version		$Id: category_alpha.php 1.0 2010-07-07 16:41:26Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>