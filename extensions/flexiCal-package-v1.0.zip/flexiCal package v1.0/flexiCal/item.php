<?php
/**
 * @version		$Id: item.php 1 2010-08-10 17:00:00Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
// first define the template name
$tmpl = $this->tmpl; // for backwards compatiblity
?>
<div id="flexicontent" class="event-item item<?php echo $this->item->id . ' type' . $this->item->type_id . ' category-' . $this->item->catid; ?>">
	<!-- BOF buttons -->
	<p class="buttons">
		<?php echo flexicontent_html::pdfbutton( $this->item, $this->params ); ?>
		<?php echo flexicontent_html::mailbutton( 'items', $this->params, null , $this->item->slug ); ?>
		<?php echo flexicontent_html::printbutton( $this->print_link, $this->params ); ?>
	</p>
	<!-- EOF buttons -->

	<!-- BOF page/category title -->
	<?php if (isset($this->item->positions['pagetitle'])) : // Note: $this->item->catid == cat id & $this->item->categoryslug == cat slug & $this->item->cats[0]->title == primary cat title ?>
		<h1 class="componentheading">
		<?php foreach ($this->item->positions['pagetitle'] as $field) : ?>
			<?php echo $field->display ?>
		<?php endforeach; ?>
		</h1>
	<?php elseif ($this->params->get( 'show_page_title', 1 ) && $this->params->get('page_title') != $this->item->title) : ?>
	    <h1 class="componentheading">
			<?php echo $this->params->get('page_title'); ?>
		</h1>
	<!-- EOF page/category title -->
	<?php endif; ?>

	<?php if ($this->params->get('show_title')) : ?>
	<!-- BOF item title -->
	<h2 class="contentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
		<?php echo $this->escape($this->fields['title']->display); ?>
	</h2>
	<!-- EOF item title -->
	<?php endif; ?>
	
	<?php if (isset($this->item->positions['subtitle'])) : ?>
	<!-- BOF subtitle block -->
	<h4 class="lineinfo subtitle">
		<?php foreach ($this->item->positions['subtitle'] as $field) : ?>
		<span class="element">
			<span class="value field_<?php echo $field->name; ?>"><?php echo $field->display; ?></span>
		</span>
		<?php endforeach; ?>
	</h4>
	<!-- EOF subtitle block -->
	<?php endif; ?>

	<?php if (isset($this->item->positions['date'])) : ?>
	<!-- BOF date block -->
	<p class="date">
		<?php foreach ($this->item->positions['date'] as $key => $field) : ?>
			<?php echo ($key == 'event-end-date' ? ' &ndash; ' : ''); ?>
			<?php if ($field->label) : ?>
			<span class="label field_<?php echo $field->name; ?>"><?php echo $field->label; ?></span>
			<?php endif; ?>
			<span class="value field_<?php echo $field->name; ?>"><?php echo $field->display[0] ?></span>
		<?php endforeach; ?>
	</p>
	<!-- EOF date block -->
	<?php endif; ?>

	<?php if ((intval($this->item->modified) !=0 && $this->params->get('show_modify_date')) || ($this->params->get('show_author') && ($this->item->creator != "")) || ($this->params->get('show_create_date')) || (($this->params->get('show_modifier')) && (intval($this->item->modified) !=0))) : ?>
	<!-- BOF item informations -->
	<p class="iteminfo">
		<?php if (($this->params->get('show_author')) && ($this->item->creator != "")) : ?>
		<span class="created">
			<?php echo JText::sprintf('FLEXI_WRITTEN_BY', $this->fields['created_by']->display); ?>
		</span>
		<?php endif; ?>
		
		<?php if (($this->params->get('show_author')) && ($this->item->creator != "") && ($this->params->get('show_create_date'))) : ?>
		|
		<?php endif; ?>

		<?php if ($this->params->get('show_create_date')) : ?>
		<span class="created">
			<?php echo JHTML::_('date', $this->fields['created']->value[0], JText::_('DATE_FORMAT_LC2')); ?>		
		</span>
		<?php endif; ?>

		<?php if (intval($this->item->modified) !=0 && $this->params->get('show_modify_date')) : ?>
		<span class="modified">
			<?php echo JText::sprintf('LAST_UPDATED2', JHTML::_('date', $this->fields['modified']->value[0], JText::_('DATE_FORMAT_LC2'))); ?>
			<?php if (($this->params->get('show_modifier')) && ($this->item->modifier != "")) : ?>
			<?php echo JText::sprintf('FLEXI_BY', $this->fields['modified_by']->display); ?>
			<?php endif; ?>
		</span>

		<?php endif; ?>
	</p>
	<!-- EOF item informations -->
	<?php endif; ?>

	<?php if (($this->params->get('show_vote', 1)) || ($this->params->get('show_favs', 1)))  : ?>
	<!-- BOF item rating, favourites -->
	<div class="itemactions">
		<?php if ($this->params->get('show_vote', 1) && isset($this->fields['voting'])) : ?>
		<span class="voting">
		<?php echo $this->fields['voting']->display; ?>
		</span>
		<?php endif; ?>
		<?php if ($this->params->get('show_favs', 1)) : ?>
		<span class="favourites">
			<?php echo $this->fields['favourites']->display; ?>
		</span>
		<?php endif; ?>
	</div>
	<!-- EOF item rating, favourites -->
	<?php endif; ?>

	<!-- BOF event afterDisplayTitle -->
	<?php if (!$this->params->get('show_intro')) :
		echo $this->item->event->afterDisplayTitle;
	endif; ?>
	<!-- EOF event afterDisplayTitle -->

	<!-- BOF event beforeDisplayContent -->
	<?php echo $this->item->event->beforeDisplayContent ?>
	<!-- EOF event beforeDisplayContent -->

	<div class="description">
	<?php echo JFilterOutput::ampReplace($this->fields['text']->display); ?>
	</div>
	
	<!-- BOF event afterDisplayContent -->
	<?php echo $this->item->event->afterDisplayContent; ?>
	<!-- EOF event afterDisplayContent -->

	<?php if (($this->params->get('show_tags', 1)) || ($this->params->get('show_category', 1)))  : ?>
	<!-- BOF item tags, favourites -->
	<div class="items-additional">
		<?php if ($this->params->get('show_category', 1)) : ?>
		<p class="categories">
			<span class="fclabel"><?php echo $this->fields['categories']->label; ?></span>
			<span class="fcvalue"><?php echo $this->fields['categories']->display; ?></span>
		</p>
		<?php endif; ?>

		<?php if ($this->params->get('show_tags', 1) && $this->fields['tags']->display) : ?>
		<p class="tags">
			<span class="fclabel"><?php echo $this->fields['tags']->label; ?></span>
			<span class="fcvalue"><?php echo $this->fields['tags']->display; ?></span>
		</p>
		<?php endif; ?>
	</div>
	<!-- EOF item tags, favourites -->
	<?php endif; ?>

	<?php if ($this->params->get('comments')) : ?>
	<!-- BOF comments -->
	<div class="comments">
	<?php
		if ($this->params->get('comments') == 1) :
			if (file_exists(JPATH_SITE.DS.'components'.DS.'com_jcomments'.DS.'jcomments.php')) :
				require_once(JPATH_SITE.DS.'components'.DS.'com_jcomments'.DS.'jcomments.php');
				echo JComments::showComments($this->item->id, 'com_flexicontent', $this->escape($this->item->title));
			endif;
		endif;
	
		if ($this->params->get('comments') == 2) :
			if (file_exists(JPATH_SITE.DS.'plugins'.DS.'content'.DS.'jom_comment_bot.php')) :
    			require_once(JPATH_SITE.DS.'plugins'.DS.'content'.DS.'jom_comment_bot.php');
    			echo jomcomment($this->item->id, 'com_flexicontent');
  			endif;
  		endif;
	?>
	</div>
	<!-- EOF comments -->
	<?php endif; ?>
</div>