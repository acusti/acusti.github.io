<?php
/**
 * @version		$Id: category_category.php 1.0 2010-08-22 16:29:00Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<div class="floattext">
	<?php if ($this->params->get('show_cat_title', 1)) : ?>
	<h2 class="flexicontent cat<?php echo $this->category->id; ?>">
		<?php echo $this->escape($this->category->title); ?>
	</h2>
	<?php endif; ?>

	<?php if (!empty($this->category->image) && $this->params->get('show_description_image', 1)) : ?>
	<div class="catimg">
		<?php echo JHTML::_('image.site', $this->category->image, 'images/stories/', NULL, NULL, $this->escape($this->category->title)); ?>
	</div>
	<?php endif; ?>
	
	<?php if ($this->params->get('show_description', 1)) : ?>
	<div class="catdescription">
		<?php echo $this->category->description; ?>
	</div>
	<?php endif; ?>
</div>