<?php
/**
 * @version		$Id: category_items.php 1 2010-06-30 12:14:08Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
// first define the template name
$tmpl = $this->tmpl;

// to activate tooltips:
//JHTML::_('behavior.tooltip'); this is controlled by "Add mootools tooltips" in flexi's global config

if ($this->items) : 

// what about an 'event type' key (if we're planning on color-coding events)?
// 	- could be stored in cat params (type w. corresponding color)

$document	=& JFactory::getDocument(); // used to include CSS declaration based on params

// prep global variables
global $dayNames, $monthNames, $today, $daysInMonth, $startDay, $colgroup, $thead, $startDateField, $endDateField, $startTimeField, $endTimeField, $typeField, $displayTitle, $titleTooltip, $displayEmpty;
$dayNames = array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
$startDay = $this->params->get('start_day', 0); // day to start week on (Sunday: 0, Monday: 1, ... could be extended)
$colgroup = $thead = '';
for ($day = 0; $day < 7; $day++) {
	$adjustedDay = ($day + $startDay) % 7;
	$colgroup .= '<col class="' . ($adjustedDay == 0 || $adjustedDay == 6 ? 'weekend' : 'weekday') . '" />';
	$thead .= '<th>' . JText::_($dayNames[$adjustedDay]) . '</th>';
}
$monthNames = array(1=>'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');// start index at 1
$today = explode(' ', date('Y n j m d'));
//$today[] = $today[0]*10000 + $today[1]*100 + $today[2];
$today[] = intval($today[0] . $today[3] . $today[4]);
//$today[0]=year, $today[1]=month int, $today[2]=day int, $today[3]=month w lead 0, $today[4]=day w lead 0, $today[5]=yyyymmd int

// initialize other variables:
$months = array();
$daysInMonth = array();// $daysInMonth[year][month][total days] (used in fcCalendarDaysInMonth())
$noTimeCount = 2500; // count for easy sorting by key in the last level of the $months array for events w. no start-time
//$m = 0;

// initialize params:
$startDateField = explode('::', $this->params->get('date_fields', 'event-start-date::event-end-date'));
$endDateField = (count($startDateField) > 1 ? $startDateField[1] : false);
$startDateField = $startDateField[0];
$startTimeField = explode('::', $this->params->get('time_fields', 'event-start-time::event-end-time'));
$endTimeField = (count($startTimeField) > 1 ? $startTimeField[1] : false);
$startTimeField = $startTimeField[0];
$typeField = $this->params->get('type_field');
$displayTitle = $this->params->get('display_title');
$titleTooltip = $this->params->get('title_tooltip', true);
$abbrMultiTitle = $this->params->get('abbr_multi_title', false);
$displayEmpty = $this->params->get('display_empty', true);
$classification = $this->params->get('classification', 2); // 0 = no classification, 1 = custom event field, 2 = category
if ($classifiKey = $this->params->get('color_key', true) || ($classification && !$displayTitle)) {
	// TODO:2010-08-18:andrewp:this is flawed, because diff groups of events will generate diff results (though color key will match)
	$classifiNames = array(); // to build index of classifications for key
	$classifiColors = array('1f65dc', '45af00', 'e53026', 'f28e0f', 'ba3cbd', '5c3bb1', 'aaa');
	/* Based on iCal default colors, where 
		blue: #1f65dc
		green: #45af00
		red: #e53026
		orange: #f28e0f
		pink: #ba3cbd
		purple: #5c3bb1
		...plus grey (#aaa) */
}

// first, foreach ($items as $item):
foreach ($this->items as $item) {
	$itemDate = array(explode('-', $item->fields[$startDateField]->value[0])); // reset array
	//$itemDate[] = explode('-', $item->fields[$startDateField]->value[0]);
	if ($endDateField && isset($item->fields[$endDateField]->value[0]))
		$itemDate[] = explode('-', $item->fields[$endDateField]->value[0]);
	
	foreach ($itemDate as &$date) {
		// we want: $date[0]=year, $date[1]=month int, $date[2]=day int, $date[3]=month w lead 0, $date[4]=day w lead 0
		$dateCopy = $date;
		$date = array_map("intval", $date); // convert string values to ints
		$date[] = $dateCopy[1]; // add back string for month...
		$date[] = $dateCopy[2]; // ...and date
	}
	unset($date); // break last reference
	
	$itemTime = false;
	if ( $startTimeField && isset($item->fields[$startTimeField]->value[0]) ) { // only pay attention to time if start-time is set
		$itemTime[] = intval(str_replace(':', '', $item->fields[$startTimeField]->value[0]));
		if ( $endTimeField && isset($item->fields[$endTimeField]->value[0]) )
			$itemTime[] = intval(str_replace(':', '', $item->fields[$endTimeField]->value[0]));
	}
	
	// does this event lie in the current month's time range?
	$dateToCheck = isset($itemDate[1]) ? $itemDate[1] : $itemDate[0];
	
	$yearDiff = $dateToCheck[0] - $today[0];
	// if event year < current year OR (event year is current year and event month < current month)
	if ( $yearDiff < 0 || ($yearDiff == 0 && $dateToCheck[1] < $today[1]) )
		continue; // skip it
	
	$monthAdjust = 0;
	if ( $yearDiff > 0 && $itemDate[0][0] == $dateToCheck[0] ) {
		$monthAdjust = $yearDiff * 12;
	}
	
	// this event needs to be displayed
	
	if ($itemDate[0] == $dateToCheck) { // single-day event
		//$monthKey = ($dateToCheck[1] + $monthAdjust) - $today[1];
		$monthKey = ($dateToCheck[1] + $monthAdjust);
		if (!isset($months[$monthKey])) // if month doesn't yet exist, add month and year as $months[month][0]
			$months[$monthKey][] = array($itemDate[0][0], $itemDate[0][1]);
		
		// $dummyItem = false;
		// $dummyItem->title = $item->title;
		// $months[$monthKey][$dateToCheck[2]][] = $dummyItem; // for testing
		$timeKey = $itemTime ? $itemTime[0] : ++$noTimeCount;
		while(isset($months[$monthKey][$dateToCheck[2]][$timeKey])) {
			$timeKey++;
		}
		// prepare classification
		if ($classification && !isset($item->cal_classification)) {
			if ($classification == 2) { // using category for classification
				foreach ($item->cats as $cat) {
					if ($cat->id == $item->catid) { // found primary category
						$classifiClass = substr($cat->slug, strpos($cat->slug, ':')+1);
						$classifiName = $cat->title;
						break;
					}
				}
			}
			else { // using custom event type
				$classifiClass = $item->fields[$typeField]->value[0];
				$classifiName = $item->fields[$typeField]->display;
			}
			if (($classifiKey || !$displayTitle) && !array_key_exists($classifiName, $classifiNames)) {
				$classifiNames[$classifiClass] = $classifiName;					
			}
			$item->cal_classification = $classifiClass;
		}
		// add the item:
		$months[$monthKey][$dateToCheck[2]][$timeKey] = $item; // i.e., $months[month from 0=currentmonth][day][time]
		
	}
	else { // multi-day event
		
		if ($sameMonth = ($itemDate[0][1] == $itemDate[1][1])) { // event w.in same month
			$i = $itemDate[0][2];
			$endDay = $itemDate[1][2];
		}
		else { // event in different months
			
			$myearAdjust = ($itemDate[1][0] - $itemDate[0][0]) * 12; // adjustment for multi-year event
			// if ($myearAdjust)
			// 	$monthAdjust = 0; // reset monthAdjust
			
			if ($itemDate[0][0] == $today[0] && $itemDate[0][1] < $today[1]) {
				// if it's the same year and before the current month, set $itemDate to 1st of today's month
				$itemDate[0][1] = $today[1];
				$itemDate[0][2] = 1;
			}
			$i = $itemDate[0][2];
			
			$endDay = 0;
			
			for ($m = $itemDate[0][1]; $m < ($itemDate[1][1]+$myearAdjust); $m++) { // loop to add in all in btwn months and their days
				if ($m <= 12) // if we haven't changed years, use date start year
					$endDay += fcCalendarDaysInMonth($itemDate[0][0], $m);
				else // if we've changed years, adjust. NOTE: only supports an event spanning 2 years
					$endDay += fcCalendarDaysInMonth($itemDate[1][0], ($m-$myearAdjust));
			}
			$endDay += $itemDate[1][2];
		}

		$index = 0;
		$first = true;
		$dayAdjust = 0;
		$yearAdjust = 0;
		$m = $itemDate[0][1];
		$y = $itemDate[0][0];
		$thisItem = 0;
		for ($i; $i <= $endDay; $i++) {
						
			if ($i > (fcCalendarDaysInMonth($y, $m) + $dayAdjust)) {
				//$dayAdjust += fcCalendarDaysInMonth($y, $m);
				$dayAdjust += $daysInMonth[$y][$m];
				// $m = ($m == 12 ? 1 : $m+1);
				$m++;
				if ($m > 12) {
					$m -= 12;
					$y++;
					$monthAdjust += 12;
				}
			}
			
			//$monthKey = ($m + $monthAdjust) - $today[1];
			$monthKey = $m + $monthAdjust;
			if (!isset($months[$monthKey])) // if month doesn't yet exist, add month and year as $months[month][0]
				$months[$monthKey][] = array($y, $m);
			
			// $dummyItem = false;
			// $dummyItem->title = $item->title;
			// $months[$monthKey][$i-$dayAdjust][] = clone($dummyItem); // for testing
			$timeKey = $itemTime ? $itemTime[0] : ++$noTimeCount;
			while(isset($months[$monthKey][$i-$dayAdjust][$timeKey])) {
				$timeKey++;
			}
			// prepare classification
			if ($classification && !isset($item->cal_classification)) {
				if ($classification == 2) { // using category for classification
					foreach ($item->cats as $cat) {
						if ($cat->id == $item->catid) { // found primary category
							$classifiClass = substr($cat->slug, strpos($cat->slug, ':')+1);
							$classifiName = $cat->title;
							break;
						}
					}
				}
				else { // using custom event type
					$classifiClass = $item->fields[$typeField]->value[0];
					$classifiName = $item->fields[$typeField]->display;
				}
				if (($classifiKey || !$displayTitle) && !array_key_exists($classifiName, $classifiNames)) {
					$classifiNames[$classifiClass] = $classifiName;					
				}
				$item->cal_classification = $classifiClass;
			}
			// add the item:
			$months[$monthKey][$i-$dayAdjust][$timeKey] = clone($item);
						
			if ($first && $abbrMultiTitle) {
				$abbrNumChar = $this->params->get('abbr_title_chars', 28);
				if (strlen($item->title) > $abbrNumChar) {
					$titleAbbr = substr($item->title, 0, $abbrNumChar); // shorten title
					$titleAbbr = substr( $titleAbbr, 0, strrpos($titleAbbr, ' ') );
				}
				else {
					$titleAbbr = $item->title;
				}
				$item->title = '…' . ( $titleAbbr ? $titleAbbr . '…' : $item->title ); // add '…'
				$first = false;
			}
			
			// echo '<pre>';
			// print_r($months[$monthKey][$i-$dayAdjust][key($months[$monthKey][$i-$dayAdjust])]);
			// echo '</pre>';
			
		}
	}
	//$m = $itemDate[1]; // for comparing next item
}
unset($item);

// add CSS based on display type (with or w.out title)
if ($displayTitle) {
	$calendarCss = '.day-eventlist li {
	padding:4px 0 1px;
	margin:3px 0 0;
	border-top:1px dotted #ccc;
}
.day-eventlist li:first-child { /* needs IE 6 fix */
	padding-top:0;
	margin-top:2px;
	border-top:0;
}';
}
elseif ($classification) {
	$calendarCss = 'table.calendar {
	width:auto;
}
table.calendar th, table.calendar td {
	width:53px;
	height:24px;
	padding:0;
	position:relative;
}
table.calendar th {
	padding:3px 6px;
	width:41px;
	height:18px;
}
.day-eventlist li {
	margin:0;
	height:24px;
	z-index:0;
	padding:0;
}
.calendar .day-eventlist {
	width:53px;
	height:24px;
	overflow:hidden;
	position:absolute;
}
.mixed.day-eventlist li {
	height:12px;
}
.day-eventlist a {
	display:block;
	width:53px;
	height:100%;
	text-indent:-999em;
	z-index:15;
}
.day-eventlist a.numbered:link, .day-eventlist a.numbered:visited, .day-eventlist a.numbered:hover {
	display:inline;
	text-indent:auto;
	color:#fff;
	text-decoration:underline;
	padding:0 2px;
}
.calendar span.day-number {
	float:none;
	display:block;
	position:absolute;
	width:12px;
	text-align:right;
	margin:3px 4px 0 35px;
	z-index:10;
}
';
	$firstTime = true;
	if (count($classifiNames)) {
		$calendarCss .= 'ul.';
		$specialCalCss = '';
		foreach ($classifiNames as $nameKey => $name) {
			$calendarCss .= ($specialCalCss ? ', ' : '') . "$nameKey.day-eventlist";
			foreach ($classifiNames as $subNameKey => $subName) {
				$specialCalCss .= ($specialCalCss ? ', ' : '') . ".calendar .$nameKey .$subNameKey";
			}
		}
		$calendarCss .= ' {
	padding:10px 0 0 4px;
	width:49px;
	height:14px;
}';
		$calendarCss .= $specialCalCss 
		. ' { /* if event types get nested, the child shouldn\'t have a bckg-color and should be displayed inline */
	background-color:transparent;
	display:inline;
	text-indent:auto;
}';
	}
}

// output classification key
if ($classifiKey && count($classifiNames)) {
	echo '<dl class="calendar-key">';
	$keyCount = 0;
	foreach ($classifiNames as $nameKey => $name) {
		echo '
	<dt class="key-color ' . $nameKey . '"></dt>
	<dd class="key-title">' . $name . '</dd>';
		$calendarCss .= "\n." . ($displayTitle ? 'calendar-key .' : '') . $nameKey . ' { background-color:#' . $classifiColors[$keyCount] . '; }'
		. ($displayTitle ? "\n.day-eventlist .$nameKey a:link, .day-eventlist .$nameKey a:visited, .day-eventlist .$nameKey a:hover { color:#" . $classifiColors[$keyCount] . '; }' : '' );
		$keyCount++;
	}
	echo "\n<dt></dt><dd style=\"clear:left;\"></dd></dl>\n";
}

$document->addStyleDeclaration($calendarCss); // add custom CSS

// now that they're categorized by month, array key sort the months (array keys are dates)
// then, foreach ($months as $key => $month); before calling function for the month,
//	 1. call function for empty months, if exist, btwn month being processed and today's month
//		-> add a special css class for those months (like 'empty')
//	 2. sort within days by time/no time set
ksort($months); // sort main array by month keys
$lastMonth = $today[1];
foreach ($months as $key => &$month) {
	
	if ($displayEmpty) {
		while ($lastMonth < ($key-1)) { // fill in empty months
			$y = $today[0];
			for ($m = $lastMonth+1; $m > 12; $m -= 12) { // in case it's sometime next year
				$y++;
			}
			fcCalendarOutputMonth(array(array($y, $m)), $this);
			$lastMonth++;
		}
	}
	
	ksort($month);
	foreach($month as &$day) {
		ksort($day); // sorts by time (if no time has been set, it goes after events with time set)
		$day = array_values($day); // reindexes array starting at 0 (don't need to keep time-based keys)
	}
	unset($day);
	
	fcCalendarOutputMonth($month, $this);
	
	$lastMonth = $key;
}
unset($month);
// echo '<pre>';
// print_r($months);
// echo '</pre>';

else : ?>
<div class="noitems"><?php echo JText::_( 'FLEXI_NO_ITEMS_CAT' ); ?></div>
<?php endif;


/**
 * Outputs a calendar for one month
 *
 * @param $monthItems	an array with $monthItems[0] containing an array w. year & month integers
 * 						and 1 - ... containing event items for each day of the month
 * @param $helper		passing $this from the object context to this function
 * 
 * @return nothing (outputs the content directly)
 * @author Andrew Patton
 **/
function fcCalendarOutputMonth($monthItems, $helper)
{
	// prep variables:
	global $dayNames, $monthNames, $today, $startDay, $colgroup, $thead, $startDateField, $endDateField, $startTimeField, $endTimeField, $typeField, $displayTitle, $titleTooltip; ?>

	<?php 	// figure out what day the 1st is
			
			// for tooltips: <li class="hasTip" title="Tooltip title:: Tooltip main text">...</li>
			// NOTE: seems that the maximum character count for the title part of the tooltip text is 53
	 ?>
	<table id="calendar-<?php echo $monthItems[0][0] . $monthItems[0][1] ?>" class="calendar<?php echo (count($monthItems) == 1 ? ' empty': '') ?>">
		<caption><?php echo /*JText::_('Month').': '.*/JText::_($monthNames[$monthItems[0][1]]).' '.$monthItems[0][0] ?></caption>
		<colgroup>
			<?php echo $colgroup ?>
		</colgroup>
		<thead>
			<tr class="sectiontableheader">
				<?php echo $thead ?>
			</tr>
		</thead>
		<tbody>
				<?php
				$dayInMonth = fcCalendarDaysInMonth( $monthItems[0][0], $monthItems[0][1] );
				$dayOfFirst = fcCalendarDayOfFirst( $monthItems[0][0], $monthItems[0][1] );
				for ($w = 0; $w < fcCalendarWeeksInMonth( $monthItems[0][0], $monthItems[0][1] ); $w++) : ?>
				<tr class="sectiontableentry<?php echo ($w % 2) + 1 ?>">
					<?php // go through each day, checking as you go for events
					
					for ($d = ($w * 7) + 1; $d <= ($w * 7 + 7); $d++) :
						// prep $thisDay and yyyymmdd int:
						$thisDay = $d - $dayOfFirst;
					 	$thisDayInt = ($monthItems[0][0]*10000 + $monthItems[0][1]*100 + $thisDay);
					
						if ( $thisDay > 0 && $thisDay <= $dayInMonth ) : ?>
					<td<?php echo ($thisDayInt < $today[5] ? ' class="day-past"' : ($today[5] == $thisDayInt ? ' id="day-today"' : '')) ?>>
						<span class="day-number"><?php echo $thisDay ?></span>
						<?php if (isset($monthItems[$thisDay])) :
								if (!$displayTitle) {
							 		// figure out how to display events (based on # of events and event types):
								 	if (count($monthItems[$thisDay]) == 1) {
										$ulClass = $numbers = '';
									} elseif (count($monthItems[$thisDay]) == 2) {
										$numbers = ($monthItems[$thisDay][0]->cal_classification == $monthItems[$thisDay][1]->cal_classification ? 1 : false); // if same event type, use numbers to represent events
										$ulClass = ($numbers ? ' ' . $monthItems[$thisDay][0]->cal_classification
												 		: ' mixed');
									}
									else { // more than 2; just use numbers to represent events
										$numbers = 1;
										$ulClass = ' ' . $monthItems[$thisDay][0]->cal_classification;
									}
								}
								else {
									$numbers = false;
								}
								?>
						<ul class="day-eventlist<?php echo $ulClass ?>">
						<?php foreach ($monthItems[$thisDay] as $monthItem) : 
							// prep tooltip text:
							// $tooltipText = $monthItem->fields[$startDateField]->value[0] 
							// 			. ( isset($monthItem->fields[$endDateField]->value[0]) ?
							// 				' - ' . $monthItem->fields[$endDateField]->value[0] : '' )
							// 			. ( isset($monthItem->fields[$startTimeField]->value[0]) ?
							// 				' ' . $monthItem->fields[$startTimeField]->value[0]
							// 				. (isset($monthItem->fields[$endTimeField]->value[0]) ? ' - ' 
							// 					. $monthItem->fields[$endTimeField]->value[0] : '')
							// 	  			: '' )
							// 			. ($titleTooltip ? ', ' . $monthItem->title : '' )
							// 	 		. '::' . flexicontent_html::striptagsandcut( $monthItem->introtext, 200 );
							$tooltipText = ($titleTooltip ? $monthItem->title . ' ' : '' )
										. ( isset($monthItem->fields[$startTimeField]->value[0]) ?
											' ' . $monthItem->fields[$startTimeField]->value[0]
											. (isset($monthItem->fields[$endTimeField]->value[0]) ? ' - ' 
												. $monthItem->fields[$endTimeField]->value[0] : '')
								  			: '' )
								 		. '::' . flexicontent_html::striptagsandcut( $monthItem->introtext, 200 );
							?>
							<li<?php if (isset($monthItem->cal_classification))
										echo ' class="' . $monthItem->cal_classification . '"'; ?>>
								<a class="hasTip<?php echo ($numbers ? ' numbered' : '') ?>" title="<?php echo	$tooltipText ?>" href="<?php echo JRoute::_(FlexicontentHelperRoute::getItemRoute($monthItem->slug, $helper->category->slug)); ?>"><?php echo ($numbers ? $numbers : $helper->escape($monthItem->title)) ?></a>
							</li>
						<?php $numbers++;
							endforeach; ?>
						</ul>
						<?php endif; // end if ($monthItems[$d])
						else : ?>
					<td class="non-day<?php echo ($thisDayInt < $today[5] ? ' day-past' : '') ?>">
						<?php endif; // end if ($d <= fcCalendarDaysInMonth($monthItems[0][0], $monthItems[0][1])) ?>
					</td>
					<?php endfor; ?>
				</tr>
				<?php // catch for logical issues:
					// if ($w == (fcCalendarWeeksInMonth( $monthItems[0][0], $monthItems[0][1] )-1) && $d < fcCalendarDaysInMonth( $monthItems[0][0], $monthItems[0][1] )) {
					// 	echo "<h4>uh oh</h4>";
					// 	$w--;
					// }
				endfor; ?>
		</tbody>
	</table>
<?php
}

// Helper functions:

// returns the day of week number corresponding to 1st of $month
function fcCalendarDayOfFirst($year, $month)
{
	global $startDay;
	return (7 + date('w', mktime(0, 0, 0, $month, 1, $year)) - $startDay) % 7;
}

// returns the number of days in $month
function fcCalendarDaysInMonth($year, $month)
{
	global $daysInMonth;
	return (!isset($daysInMonth[$year][$month]) ? $daysInMonth[$year][$month] = date('t', mktime(0, 0, 0, $month, 1, $year)) : $daysInMonth[$year][$month]);
}

//returns the number of weeks in $month
function fcCalendarWeeksInMonth($year, $month)
{
	return ceil((fcCalendarDaysInMonth($year, $month) + fcCalendarDayOfFirst($year, $month)) / 7);
}

?>
