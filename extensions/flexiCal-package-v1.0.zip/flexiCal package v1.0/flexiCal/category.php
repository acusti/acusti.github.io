<?php
/**
 * @version		$Id: category.php 1 2010-06-30 13:00:43Z andrewp $
 * @package		flexiCal template
 * @author		Andrew Patton
 * @copyright	Copyright (C) 2010 Pure Cobalt. All rights reserved.
 * @license		GNU/GPL v2
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<div id="flexicontent" class="flexicontent">

<p class="buttons">
	<?php // BOF buttons
	//echo flexicontent_html::addbutton( $this->params );
	echo flexicontent_html::printbutton( $this->print_link, $this->params );
	echo flexicontent_html::mailbutton( 'category', $this->params, $this->category->slug ); 
	// EOF buttons ?>
</p>

<?php // BOF page title
	if ($this->params->get( 'show_page_title', 1 ) && $this->params->get('page_title') != $this->category->title) : ?>
    <h1 class="componentheading">
		<?php echo $this->params->get('page_title'); ?>
	</h1>
	<?php endif; // EOF page title

	// BOF category description
	if (($this->category->id > 0) && ((!empty($this->category->image) && $this->params->get('show_description_image', 1)) || ($this->params->get('show_description', 1)) || ($this->params->get('show_cat_title', 1)))) :
	echo $this->loadTemplate('category');
	endif;
	// EOF category description
	
	// BOF sub-categories
	//only show this part if subcategories are available
	if (count($this->categories) && $this->category->id > 0 && $this->params->get('show_subcategories')) :
	echo $this->loadTemplate('subcategories');
	endif;
	// EOF sub-categories
	
	// BOF item list display
	echo $this->loadTemplate('items');
	// EOF item list display -->

	// BOF pagination
	if ($this->params->get('show_pagination', 2) != 0) : ?>
	<div class="pageslinks">
		<?php echo $this->pageNav->getPagesLinks(); ?>
	</div>

	<?php if ($this->params->get('show_pagination_results', 1)) : ?>
	<p class="pagescounter">
		<?php echo $this->pageNav->getPagesCounter(); ?>
	</p>
	<?php
		endif;
	endif; 
	// EOF pagination ?>

</div>